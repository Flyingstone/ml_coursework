#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Dec 17 10:17:24 2016

@author: admin
"""

import numpy as np

def norm(vector):
	if sum(vector)==0:
		return vector
	return vector/sum(vector)
def maxIndex(array):
	Index=0
	maxValue=array[0]
	for i in range(1,len(array)):
		if array[i]>maxValue:
			Index = i
			maxValue = array[i]
	return Index

def estimatePXY(x, y, xrange, yrange, smooth=0):
	#xrange是x的取值范围，如x从0到100则xrange是101
	expectCount = np.zeros(xrange*yrange).reshape(xrange,yrange)
	for i in range(len(x)):
		expectCount[x[i]] += y[i]

	if smooth >= 0 :
		expectCount += 0.01
	expectCount_old = expectCount.copy()
	if smooth >= 1 :
		for i in range(1,len(expectCount)):
			expectCount[i] += 0.5*expectCount_old[i-1]
		for i in range(len(expectCount)-1):
			expectCount[i] += 0.5*expectCount_old[i+1]
	if smooth >= 2 :
		for i in range(2,len(expectCount)):
			expectCount[i] += 0.2*expectCount_old[i-2]
		for i in range(len(expectCount)-2):
			expectCount[i] += 0.2*expectCount_old[i+2]
	for j in range(yrange):
		expectCount[:,j]=norm(expectCount[:,j])
	return expectCount
def estimatePY(y, smooth=0):
	expectCount = np.sum(y,axis=0)
	if smooth>=0 :
		expectCount += 0.1
	expectCount = norm(expectCount)
	return expectCount
def estimate(x, PY, PXYlist):
	estimateY = []
	for i in range(len(PY)):
		estimateY.append(PY[i])
		for j in range(len(x)):
			estimateY[i] *= PXYlist[j][x[j], i]
	estimateY = norm(np.array(estimateY))
	return estimateY
def estimateList(xList, PY, PXYlist):
	return np.array(list(map(lambda m: estimate(m, PY, PXYlist), xList)))
	

#################----test----###################
#x=np.array([[0,0],[0,1],[0,1],[0,0],[0,0],[1,0],[1,1],[1,1],[1,2],[1,2],[2,2],[2,1],[2,1],[2,2],[2,2]])
#y=np.array([[0,1],[0,1],[1,0],[1,0],[0,1],[0,1],[0,1],[1,0],[1,0],[1,0],[1,0],[1,0],[1,0],[1,0],[0,1]])
#print(estimatePY(y))
#print(estimatePXY(x[:,0],y,3,2,-1))
#print(estimatePXY(x[:,1],y,3,2,-1))
#print(estimate([1,0],estimatePY(y,-1),[estimatePXY(x[:,0],y,3,2,-1),estimatePXY(x[:,1],y,3,2,-1)]))