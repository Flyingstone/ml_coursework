#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Dec 18 21:44:12 2016

@author: leimingda
"""
from semiSupervisedBayes import *
import numpy as np
import csv

#--------------process data-----------------
fullData = np.array(list(csv.reader(open('semiSupervisedBayes.csv'))))
#inputData = fullData[:,-5:-1].astype(np.double)
inputData = fullData[:,-12:-5].astype(np.double)
for i in range(len(inputData[0])):
	maxValue = max(inputData[:,i])
	minValue = min(inputData[:,i])
	inputData[:,i]=np.floor((inputData[:,i]-minValue)/(maxValue-minValue)*20).astype(np.int)
outputData = fullData[:,-12].astype(np.double)
outputData = np.around((outputData-min(outputData))/(max(outputData)-min(outputData))*20).astype(np.int)
for i in range(len(outputData)):
	if outputData[i]>10:
		outputData[i]=10
unlabeledList=[]
labeledList=[]
for i in range(len(inputData)):
	if i%5==2:
		labeledList.append(i)
	else:
		unlabeledList.append(i)
vector_outputData = np.zeros(len(outputData)*11).reshape(len(outputData),11)
for i in range(len(vector_outputData)):
	vector_outputData[i][outputData[i]]=1

#---------------data initialize-------------------
init_smooth_level = 2
PXYlist = []
for i in range(len(inputData[0])):
	PXYlist.append(estimatePXY(inputData[labeledList,i], vector_outputData[labeledList], 21, 11, init_smooth_level))
PY = estimatePY(vector_outputData[labeledList], 1)
vector_outputData[unlabeledList] = estimateList(inputData[unlabeledList],PY,PXYlist)
PY_old = PY.copy()+1

#---------------write SupervisedBayesResult----------------
with open('SupervisedBayesResult.csv','wb') as f:
	for item in vector_outputData:
		line = str(maxIndex(item)) + '\n'
		f.write(line.encode('utf-8'))

#---------------EM---------------------		
smooth_level = -1
while (abs(PY_old-PY)>0.002).any():
	count = 0
	PY_old = PY.copy()
	PXYlist = []
	for i in range(len(inputData[0])):
		PXYlist.append(estimatePXY(inputData[:,i], vector_outputData, 21, 11, smooth_level))
	PY = estimatePY(vector_outputData, smooth_level)
	vector_outputData[unlabeledList] = estimateList(inputData[unlabeledList],PY,PXYlist)
	for i in range(len(vector_outputData)):
		temp=0
		for j in range(len(vector_outputData[0])):
			temp += j*vector_outputData[i,j]
		count += abs(temp-outputData[i])
#	for i in range(len(vector_outputData)):
#		count += abs(maxIndex(vector_outputData[i])-outputData[i])
#	print(count/len(outputData))
#	print("PY :",PY)

#---------------write SemiSupervisedBayesResult----------------
with open('semiSupervisedBayesResult.csv','wb') as f:
	for item in vector_outputData:
		line = str(maxIndex(item)) + '\n'
		f.write(line.encode('utf-8'))
		