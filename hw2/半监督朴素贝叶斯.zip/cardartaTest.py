#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Dec 18 20:02:08 2016

@author: leimingda
"""

from semiSupervisedBayes import *
import numpy as np

def randomChoices(originList, k):
	#从originList中随机选出不重复的k个
	if len(originList)<k:
		print("list is too short")
		return None
	nowList=originList.copy()
	choicesList=[]
	for i in range(k):
		num = np.random.randint(0, len(nowList))
		choicesList.append(nowList[num])
		del nowList[num]
	return choicesList
	
def randomDevide(originList, p=0.5):
	#把一个array随机分为两组, 以p的概率分到第一组，1-p概率分到第二组
	list1 = []
	list2 = []
	for i in range(len(originList)):
		if np.random.random_sample()<p:
			list1.append(i)
		else :
			list2.append(i)
	return originList[list1],originList[list2]
	
data=[line.replace("\n","").replace("low","0").replace("med","1").replace("vhigh","3").replace("high","2").replace("5more","5").replace("more","5").replace("unacc","0").replace("acc","1").replace("vgood","3").replace("good","2").replace("small","0").replace("big","1").split(',') for line in open('car.data').readlines()]
data=np.array(data).astype(np.int)
for i in range(len(data)):
	if data[i, 3]==2:
		data[i, 3]=0
	elif data[i, 3]==4:
		data[i, 3]=1
	elif data[i, 3]==5:
		data[i, 3]=2
data[:,2]=data[:,2]-2
dataIn = data[:,:5]
dataOut = np.zeros(len(data)*4).reshape(len(data),4)
for i in range(len(dataOut)):
	dataOut[i,data[i,-1]]=1
trainDataList,testDataList = randomDevide(np.array(range(len(dataIn))))
trainIn = dataIn[trainDataList]
trainOut = dataOut[trainDataList]
testIn = dataIn[testDataList]
testOut = dataOut[testDataList]
labelList, unlabelList = randomDevide(np.array(range(len(trainDataList))), 0.1)

init_smooth_level = 2
PXYlist = []
for i in range(len(trainIn[0])):
	PXYlist.append(estimatePXY(trainIn[labelList,i], trainOut[labelList], max(dataIn[:,i])+1, 4, init_smooth_level))
PY = estimatePY(trainOut[labelList], init_smooth_level)
trainOut[unlabelList] = estimateList(trainIn[unlabelList], PY, PXYlist)
PY_old = PY.copy()+1

count = 0
for i in range(len(testIn)):
	if maxIndex(estimate(testIn[i],PY,PXYlist))==data[testDataList[i],-1]:
		count += 1
print("test set correct rate:",count/len(trainDataList))


smooth_level = 2
while (abs(PY_old-PY)>0.002).any():
	PY_old = PY.copy()
	PXY_list = []
	for i in range(len(trainIn[0])):
		PXY_list.append(estimatePXY(trainIn[:,i], trainOut, max(dataIn[:,i])+1, 4, smooth_level))
	PY = estimatePY(trainOut, smooth_level)
	trainOut[unlabelList] = estimateList(trainIn[unlabelList], PY, PXYlist)
	count = 0
	for i in range(len(trainIn)):
		if maxIndex(trainOut[i])==data[trainDataList[i],-1]:
			count += 1
	print("train set correct rate:",count/len(trainDataList))
	count = 0
	for i in range(len(testIn)):
		if maxIndex(estimate(testIn[i],PY,PXYlist))==data[testDataList[i],-1]:
			count += 1
	print("test set correct rate:",count/len(trainDataList))
